# Uruchomienie
- `npm install` (zainstalowanie pakietów NPM)
- `grunt build` (zbudowanie projektu do katalogu build)
- `grunt watch` (automatyczne budowanie projektu po wykryciu zmian w plikach)

# Wymagania
- zainstalowany w systemie Node.js
- zainstalowane globalnie pakiety grunt i grunt-cli