'use strict';

module.exports = function(grunt){
    require('load-grunt-tasks')(grunt);
    require('time-grunt')(grunt);

    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-mustache-render');

    grunt.initConfig({
        watch: {
            all: {
                files: ['src/{,**/}*.*'],
                tasks: ['build']
            }
        },
        copy: {
            assets: {
                files: [
                    {
                        expand: true,
                        cwd: 'src/assets',
                        src: '**',
                        dest: 'build/assets/'
                    }
                ]
            }
        },
        mustache_render: {
            options: {},
            dist: {
                options: {
                    data: '',
                    directory: 'src/templates',
                    escape: false
                },
                files: [
                    {'build/index.html': 'src/templates/index.mustache'},
                    {'build/restaurant.html': 'src/templates/restaurant.mustache'},
                    {'build/menu.html': 'src/templates/menu.mustache'},
                    {'build/cart.html': 'src/templates/cart.mustache'},
                    {'build/order.html': 'src/templates/order.mustache'},
                    {'build/confirmation.html': 'src/templates/confirmation.mustache'}
                ]
            }
        }
    });

    grunt.registerTask('serve', [
        'watch'
    ]);

    grunt.registerTask('build', [
        'copy',
        'mustache_render'
    ]);

};