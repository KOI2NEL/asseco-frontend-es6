/*global Storages */
var Order = (function () {
    "use strict";

    var instance;

    return {
        getInstance: function () {
            if (!instance) {
                instance = init();
            }
            return instance;
        }
    };

    function init() {
        var order = getEmptyOrderObject(),
            product = new Product(),
            storage = Storages.localStorage,
            storageOrderName = 'order',
            storageOrderListName = 'orderList';

        // próba przywrócenia zamówienia ze Storage
        restoreOrderFromStorage();

        // przeliczenie zamówienia
        checkout();

        return {
            resetOrder: resetOrder,
            setNewOrderFromRestaurant: setNewOrderFromRestaurant,
            getOrderDetails: getOrderDetails,
            addProductToCart: addProductToCart,
            removeProductFromCart: removeProductFromCart,
            getOrderValue: getOrderValue,
            setProductAmount: setProductAmount,
            setRecipientData: setRecipientData,
            save: save
        };

        /**
         * Funkcja zwracająca sumę wartości zamówienia
         * @returns {number}
         */
        function getOrderValue() {
            return order.orderValue;
        }

        /**
         * Funkcja zwracająca pusty szablon zamówienia
         * @returns {object}
         */
        function getEmptyOrderObject() {
            return {
                cart: [],
                restaurantId: null,
                orderValue: 0,
                recipient: {
                    name: '',
                    address: '',
                    email: '',
                    phone: ''
                }
            };
        }

        /**
         * Funkcja resetująca zamówienie
         */
        function resetOrder() {
            removeOrderFromStorage();
            order = getEmptyOrderObject();
        }

        /**
         * Funkcja ustawiająca ID restauracji w zamówieniu
         * @param {number} restaurantId
         */
        function setNewOrderFromRestaurant(restaurantId) {
            resetOrder();
            setRestaurantId(restaurantId);
        }

        /**
         * Funkcja ustawiająca pole ID restauracji
         * @param {number} id
         */
        function setRestaurantId(id) {
            order.restaurantId = id;
            saveOrderInStorage();
        }

        /**
         * Funkcja zwracająca obiekt zamówienia
         * @returns {object}
         */
        function getOrderDetails() {
            return order;
        }

        /**
         * Funkcja dodająca produkt do koszyka
         * @param {number} productId
         * @returns {boolean}
         */
        function addProductToCart(productId) {
            if (!productId || typeof productId !== 'number') {
                return false;
            }

            var productItem = product.getProductById(productId);

            if (!productItem) {
                return false;
            }

            var productInCart = getProductFromCartById(productId);

            if (!productInCart) {
                order.cart.push({
                    id: productItem.id,
                    price: productItem.price,
                    name: productItem.name,
                    amount: 1
                });
            } else {
                productInCart.amount = productInCart.amount + 1;
            }

            checkout();
        }

        /**
         * Funkcja wyszukująca w koszyku produkt po jego ID
         * @param {number} id
         * @returns {*}
         */
        function getProductFromCartById(id) {
            // funkcja zwraca REFERNCJĘ (odniesienie, wskaźnik) do elementu z koszyka
            return order.cart.find(function (product) {
                return product.id === id;
            });
        }

        /**
         * Funkcja wyszukująca indeks produktu w koszyku produkt po jego ID
         * @param {number} id
         * @returns {*}
         */
        function getProductIndexFromCartById(id) {
            // funkcja zwraca REFERNCJĘ (odniesienie, wskaźnik) do elementu z koszyka
            return order.cart.findIndex(function (product) {
                return product.id === id;
            });
        }

        /**
         * Funkcja kasująca produkt z koszyka
         * @param {number} productId
         */
        function removeProductFromCart(productId) {
            var productItemIndex = getProductIndexFromCartById(productId);

            if (productItemIndex !== -1) {
                order.cart.splice(productItemIndex, 1);
            }

            checkout();
        }

        /**
         * Funkcja ustawiająca ilość sztuk produktu w koszyku
         * @param {number} productId
         * @param {number} amount
         */
        function setProductAmount(productId, amount) {
            var productInCart = getProductFromCartById(productId);

            if (productInCart) {
                productInCart.amount = amount;
            }

            checkout();
        }

        /**
         * Funkcja przeliczająca zawartość zamówienia
         */
        function checkout() {

            // pętla po tablicy koszyka
            // liczymy ilość * cena
            // suma wyliczonych wartości
            // zapis wyliczonej wartości zamówienia w orderValue
            var orderValue = 0; // wartość w zł

            order.cart.forEach(function (cartItem) {
                // obliczenia wykonane na groszach, czyli liczbie całkowitej
                var cartItemValue = cartItem.price * 100 * cartItem.amount; // wynik w groszach
                orderValue = (orderValue * 100 + cartItemValue) / 100; // wynik w zł
            });

            // obliczenia na groszach aby uniknać błędów przeliczania liczb zmiennoprzecinkowych

            order.orderValue = orderValue;

            saveOrderInStorage();
            sendCheckoutEvent();
        }

        /**
         * Funkcja wysyłająca EVENT o zakończeniu przeliczania koszyka
         */
        function sendCheckoutEvent() {
            $('body').trigger('cartCheckout');
        }

        /**
         * Funkcja zapisująca zamówienie w storage
         */
        function saveOrderInStorage() {
            storage.set(storageOrderName, order);
        }

        /**
         * Funkcja przywracająca zamówienie ze storage
         */
        function restoreOrderFromStorage() {
            if (storage.isSet(storageOrderName)) {
                order = storage.get(storageOrderName);
            }
        }

        /**
         * Funkcja kasująca zamówienie ze storage
         */
        function removeOrderFromStorage() {
            storage.remove(storageOrderName);
        }

        /**
         * Funkcja uzupełniająca dane odbiorcy
         * @param {object} recipientData
         */
        function setRecipientData(recipientData) {
            recipientData.forEach(function (field) {
                if (order.recipient[field.name] !== undefined) {
                    order.recipient[field.name] = field.value;
                }
            });
        }

        /**
         * Funkcja zapisująca zamówienie do listy zamówień w localStorage
         * a następnie czyszcząca bieżące zamówienie
         */
        function save() {
            var orderList = [];

            if (storage.isSet(storageOrderListName)) {
                orderList = storage.get(storageOrderListName) || [];
            }

            orderList.push(order);
            storage.set(storageOrderListName, orderList);
            removeOrderFromStorage();
            resetOrder();
        }
    }
})();