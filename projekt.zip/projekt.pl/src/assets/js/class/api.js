function Api() {

    var placesApiKey = 'AIzaSyCED7Pa5dMrRPZmm91py9mpShZr_0m1Fn4';
    var apiLocationUrl = 'http://maps.google.com/maps/api/geocode/json';
    var apiPlacesUrl = 'https://cors-anywhere.herokuapp.com/https://maps.googleapis.com/maps/api/place/nearbysearch/json';

    return {
        getLocationByAddress: getLocationByAddress,
        getRestaurantsForLocation: getRestaurantsForLocation
    };


    function getLocationByAddress(address) {
        return $.ajax({
            url: apiLocationUrl,
            data: {
                address: address
            }
        });
    }

    /**
     *
     * @param {object} location
     * @param {string} [radius]
     */
    function getRestaurantsForLocation(location, radius) {
        location = location || {};
        radius = radius || '500';

        var data = {
            radius: radius,
            type: 'restaurant',
            keyword: 'pizza',
            location: location.lat + ',' + location.lng,
            key: placesApiKey
        };

        return $.ajax({
            url: apiPlacesUrl,
            data: data
        });

    }
}