function Restaurant() {

    // TODO: rozbudować o kolejne pola opisujące restaurację, docelowo lista ma być ładowana ajaxem
    var restaurantList = [
        {
            id: 1,
            name: 'KFC'
        },
        {
            id: 2,
            name: 'MC Donalds'
        },
        {
            id: 3,
            name: 'U Chińczyka'
        }
    ];

    this.getList = function () {
        return restaurantList || [];
    };

    this.getRestaurantById = function (id) {
        if (!id || typeof id !== 'number') {
            return false;
        }

        var restaurant = false;

        // TODO: podłączyć bibliotekę Underscore lub Lodash i użyć _.filter() do zwrócenia obiektu restauracji
        restaurantList.forEach(function (item) {
            if (item.id === id) {
                restaurant = item;
            }
        });

        return restaurant;
    };
}