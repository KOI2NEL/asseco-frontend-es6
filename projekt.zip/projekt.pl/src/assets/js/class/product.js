function Product() {

    var productList = [
        {
            id: 1,
            name: 'Margerita Królewska',
            description: 'pomidory koktajlowe, świeża bazylia, ser mozzarella bufalo',
            price: 33.90
        },
        {
            id: 2,
            name: 'Margerita',
            description: 'Klasyczna na grubym cieście',
            price: 18.90
        },
        {
            id: 3,
            name: 'Salami',
            description: 'Salami, Klasyczna na grubym cieście',
            price: 26.90
        },
        {
            id: 4,
            name: 'Kasa',
            description: 'Szynka, Klasyczna na grubym cieście',
            price: 26.90
        }
    ];

    this.getProducts = function() {
        return productList || [];
    };

    this.getProductById = function(id) {
        if (!id || typeof id !== 'number') {
            return false;
        }

        var product = false;

        productList.forEach(function (item) {
            if (item.id === id) {
                product = item;
            }
        });

        return product;
    };

}