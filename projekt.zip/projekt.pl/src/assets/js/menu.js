(function () {
    "use strict";

    var productObject = new Product(),
        productListContainer = $('#productList'),
        productList = productObject.getProducts(),
        order = Order.getInstance();

    if (productList.length) {
        productList.forEach(function (product) {
            var productItem = $('<div>' +
                '<h2>' + product.name + '</h2>' +
                '<p>' + product.description + '</p>' +
                '<p>Cena: '+product.price+' zł - ' +
                '<a href="#">Dodaj do koszyka</a>' +
                '</p>' +
                '</div>');

            productItem.find('a').click(function (event) {
                event.preventDefault();
                addToCart(product.id);
            });

            productListContainer.append(productItem);
        });
    }

    function addToCart(id) {
        console.log('Dodaje do koszyka produkt o ID: ', id);
        order.addProductToCart(id);
        console.log(order.getOrderDetails());
    }
})();

