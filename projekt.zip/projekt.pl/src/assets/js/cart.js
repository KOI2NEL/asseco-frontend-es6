(function () {
    'use strict';

    // wczytujemy instancję zamówienia
    var order = Order.getInstance();

    // zakładamy nasłuch na event z klasy zamówienia Order
    $('body').on('cartCheckout', function () {
        // generujemy zawartość koszyka
        showCart();
    });

    // generujemy zawartość koszyka
    showCart();

    /**
     * Funkcja generująca zawartość koszyka
     */
    function showCart() {
        // łapiemy węzły DOM
        var cartTableContainer = $('#cartTable'),
            cartTableContainerBody = cartTableContainer.find('tbody'),
            cartTableContainerFooter = cartTableContainer.find('tfoot');

        // czyścimy zawartość TBODY i TFOOT tabeli
        cartTableContainerBody.html('');
        cartTableContainerFooter.html('');

        // pobieramy zawartość zamówienia
        var orderDetails = order.getOrderDetails();

        // sprawdzenie czy mamy zamówienie
        if (!orderDetails || !orderDetails.cart.length) {
            return;
        }

        //TODO: dodać obsługę widoku pustego koszyka

        // w pętli dla każdego produktu w koszyku generujemy wiersze tabeli
        orderDetails.cart.forEach(function (product, index) {

            // szablon wiersza
            var productRow = $('<tr>' +
                '<td>' + (index + 1) + '.</td>' +
                '<td>' + product.name + '</td>' +
                '<td><input type="number" min="1" max="99" value="' + product.amount + '" class="amountInput"></td> ' +
                '<td>' + product.price.toFixed(2) + '</td>' +
                '<td>' + (product.price * product.amount).toFixed(2) + '</td>' +
                '<td>' +
                '<button type="button" class="btn btn-default btn-xs" aria-label="Usuń">' +
                '<span class="glyphicon glyphicon-remove" aria-hidden="true"></span>' +
                '</button>' +
                '</td>' +
                '</tr>');

            // założenie eventu na przycisk usuń
            productRow.find('button').click(function () {
                order.removeProductFromCart(product.id);
            });

            // założenie eventu na pole input
            productRow.find('input').change(function () {
                order.setProductAmount(product.id, $(this).val());
            });

            // dodanie wygenerowanego wiersza do tabeli
            cartTableContainerBody.append(productRow);
        });

        // szablon wiersza podsumowania
        var cartTableSummary = $('<tr>' +
            '<td colspan="4">RAZEM:</td>' +
            '<td>' + orderDetails.orderValue.toFixed(2) + '</td>' +
            '<td></td>' +
            '</tr>'
        );

        // dodanie wiersza podsumowania do tabeli
        cartTableContainerFooter.append(cartTableSummary);
    }

    /**
     * Funkcja walidująca formularz
     */
    $("#formOrder").validate({
        // obsługa potwierdzenia formularza
        submitHandler: function(form) {
            order.setRecipientData($(form).serializeArray());
            order.save();
            document.location.href = 'confirmation.html';
        },
        // reguły walidacji
        rules: {
            name: {
                required: true
            },
            address: {
                required: true
            },
            personaldata: {
                required: true
            },
            email: {
                required: true,
                email: true
            },
            phone: {
                required: true,
                minlength: 9
            }
        },
        // komunikaty walidacji
        messages: {
            name: "Podaj swoje imię i nazwisko",
            address: "Podaj swój adres",
            email: {
                required: "Podaj swój e-mail",
                email: "Adres e-mail jest nieprawidłowy"
            },
            phone: {
                required: "Podaj swój telefon",
                minlength: $.validator.format("Telefon powinien mieć min. 9 cyfr")
            },
            personaldata: "Zaznacz zgodę na przetwarzanie danych osobowych"
        },
        // element w jakim mają się wyświetlać błędy
        errorElement: 'div',
        // funkcja wstrzykująca element błędu do formularza
        errorPlacement: function (error, element) {
            if (element.attr('type') === 'checkbox') {
                element.parents('div.checkbox').append(error);
            } else {
                error.insertAfter(element);
            }

        }
    });

})();