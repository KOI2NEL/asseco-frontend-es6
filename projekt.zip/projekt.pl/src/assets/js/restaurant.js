/*global $ */
(function () {
    "use strict";

    var restaurant = new Restaurant(),
        restaurantListContainer = $('#restaurantList'),
        restaurantList = restaurant.getList(),
        order = Order.getInstance();

    order.resetOrder();

    if (restaurantList.length) {
        restaurantList.forEach(function (restaurant) {
            var restaurantItem = $('<li><a href="#">' + restaurant.name + '</a></li>');

            restaurantItem.find('a').click(function (event) {
                event.preventDefault();
                chooseRestaurant(restaurant.id);
            });

            restaurantListContainer.append(restaurantItem);
        });
    }

    function chooseRestaurant(id) {
        order.setNewOrderFromRestaurant(id);
        document.location.href = 'menu.html';
    }

})();