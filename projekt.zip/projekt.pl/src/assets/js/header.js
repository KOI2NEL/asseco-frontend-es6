(function () {
    "use strict";

    var order = Order.getInstance();

    $('body').on('cartCheckout', function () {
        setCartSummary();
    });

    setCartSummary();

    function setCartSummary() {
        $('#cartSummary').text(order.getOrderValue().toFixed(2));
    }

})();