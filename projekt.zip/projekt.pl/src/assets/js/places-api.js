(function () {

    var api = new Api();

    // walidacja i obsługa formularza na stronie głównej
    $('#formSearch').validate({
        submitHandler: function(form) {

            // pobieramy z formularza wpisaną frazę
            var search = $(form).serializeArray(),
                searchQuery = search[0].value;

            api
                // pobieramy geolokalizację dla wpisanej frazy
                .getLocationByAddress(searchQuery)
                // z odpowiedzi wyciągamy obiekt ze współrzędnymi geolokalizacji
                .then(function (response) {
                    return response.results[0].geometry.location;
                })
                // przekazujemy współrzędne do kolejnej metody z API
                .then(api.getRestaurantsForLocation)
                // przetwarzamy odpowiedź - lista restauracji
                .then(function (response) {
                    response.results.forEach(function(restaurant){
                        console.log(restaurant.name + ' - ' + restaurant.vicinity);
                    });
                });
        },
        rules: {
            localization: {
                required: true
            }
        }
    });


})();